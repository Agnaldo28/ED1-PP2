#include "Estacionamento.h"


void IniciarPilha(TipoPilha *pilha, int tamanho)
	{
		pilha->topo = NULL;
		pilha->tamanho = tamanho;
		pilha->veiculos = 0;
	}


	int VerificaPilhaVazia(TipoPilha *pilha)
	{
		return (pilha->topo == NULL);
	}


	void push(VeiculoEstacionado valor, TipoPilha *pilha)
	{
		TipoNo *aux;
		aux = (TipoNo *) malloc(sizeof(TipoNo));
		aux -> valor = valor;
		aux->prox = pilha->topo;
		pilha->topo = aux;
		pilha->veiculos++;
	}


	VeiculoEstacionado pop(TipoPilha *pilha)
	{
		TipoNo *aux;
		VeiculoEstacionado valor;

		if (VerificaPilhaVazia(pilha)) {
			valor.matricula = 0;
			valor.hora = 0;
			return valor;
		}

		aux = pilha->topo;
		pilha->topo = aux->prox;
		valor = aux->valor;
		free(aux);
		pilha->veiculos--;
		return valor;
	}
	
	void apresentarPilha(TipoPilha *pilha)
	{
		int i;
		VeiculoEstacionado valor;
		for(i=0; i<= pilha->veiculos;i++) 
		{
			valor = pop(pilha);
			printf ("Veiculo: %d : %dh \n", valor.matricula, valor.hora);
		}
	}


