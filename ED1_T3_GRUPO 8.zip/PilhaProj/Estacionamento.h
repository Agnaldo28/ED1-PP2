#include <stdio.h>
#include <stdlib.h>

typedef struct Veiculo
{
	int matricula;
	int hora;
	
} VeiculoEstacionado;


typedef struct No {
	VeiculoEstacionado valor;
	struct No *prox;
}TipoNo;

typedef struct Pilha {
	TipoNo *topo;
	int tamanho;
	int veiculos;
}TipoPilha;



void IniciarPilha(TipoPilha *pilha, int tamanho);
int VerificaPilhaVazia(TipoPilha *pilha);
void push(VeiculoEstacionado valor, TipoPilha *pilha);
VeiculoEstacionado pop(TipoPilha *pilha);
void apresentarPilha(TipoPilha *pilha);
