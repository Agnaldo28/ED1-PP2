#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "Estacionamento.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
typedef enum  
{
	VERMELHO = 4,
	
	DOURADO = 6,//1,
	VERDE = 2,
	BRANCO_CLARO = 15,
	BRANCO = 15, //15 8 7
 	TABELA_CLARA = 246,
	TABELA_AZUL = 7,
	TABELA_ESCURA = 112,
	TABELA_CINZA = 128,
	TABELA_DOURADA = 110	
}COR;

void apresentarMensagemPilhaVazia();
void mostraCursor(int mostrar);
void alterarCorDaConsola(COR cor);
void apresentarTelaIncial();

int main(int argc, char *argv[]) 
{
	int const vagas = 8;
	
	int i, menu = 0;
	VeiculoEstacionado veiculo;
	TipoPilha *pilha;
	pilha = (TipoPilha *) malloc (sizeof(TipoPilha));
	IniciarPilha(pilha, vagas);

	for (i=0;i<vagas;i++) 
	{
		
	}
	
	

	
	while(menu != 5)
	{
		switch(menu)
		{	
				case 0:
				apresentarTelaIncial();
				scanf("%d", &menu);
				break;
			case 1:
				printf("Introduza a matricula: ");
				scanf("%d",&veiculo.matricula);
				printf("Introduza a hora: ");
				scanf("%d",&veiculo.hora);
				push(veiculo, pilha);
				printf("Entrou: %d : %dh \n", veiculo.matricula, veiculo.hora);
				system("pause");
				menu = 0;
				break;		
			case 2:
				veiculo = pop(pilha);
				printf("Saiu: %d : %dh \n", veiculo.matricula, veiculo.hora);
				system("pause");
				menu = 0;
				break;
			case 3:
				printf("Vagas Disponiveis: %d", vagas - pilha->tamanho);
				menu = 0;
				system("pause");
				break;
			case 4:
				apresentarPilha(pilha);
				system("pause");
				menu = 0;
				break;
			default:
				menu = 0;
				break;
		}
	}
	return 0;
}

void apresentarMensagemPilhaVazia()
{
	alterarCorDaConsola(TABELA_CINZA);
	printf("\t\t\t\t!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
	printf("\t\t\t\t!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
	printf("\t\t\t\t!!!!!!!!!!");
	alterarCorDaConsola(VERMELHO);
	printf("ESTACIONAMENTO VAZIO !");
	alterarCorDaConsola(TABELA_CINZA);
	printf("!!!!!!!!!!\n");
	printf("\t\t\t\t!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
	printf("\t\t\t\t!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");

	
	alterarCorDaConsola(TABELA_DOURADA);
	printf("\n\n");
	printf("\t\t\t");	
	system("echo PRESSIONE QUALQUER TECLA PARA VOLTAR A TELA INICIAL");
	mostraCursor(0);
	alterarCorDaConsola(BRANCO);
	system("pause > null");
}

void mostraCursor(int mostrar)
{
    HANDLE consola = GetStdHandle(STD_OUTPUT_HANDLE);

    CONSOLE_CURSOR_INFO   infoCursor;

    GetConsoleCursorInfo(consola, &infoCursor);
    infoCursor.bVisible = mostrar;
    SetConsoleCursorInfo(consola, &infoCursor);
}

void alterarCorDaConsola(COR cor)
{
	HANDLE consola;
	consola = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(consola, cor);
}



void apresentarTelaIncial()
{	
	alterarCorDaConsola(BRANCO);	
	system("cls");
	printf(".###############################################################################################.\n");
	printf(".##..");
	alterarCorDaConsola(TABELA_CLARA);
	printf("Estacionar         ");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("- 1 -");
	alterarCorDaConsola(BRANCO);
	printf(".#####################..");
	alterarCorDaConsola(TABELA_CLARA);
	printf("Remover carro       ");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("- 2 -");
	alterarCorDaConsola(BRANCO);
	printf(".               ##.\n");
	
	printf(".##..");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("Verificar vaga     ");
	alterarCorDaConsola(TABELA_CLARA);
	printf("- 3 -");
	alterarCorDaConsola(BRANCO);
	printf(".#####################..");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("Mostrar carros estacionados        ");
	alterarCorDaConsola(TABELA_CLARA);
	printf("- 4 -");
	alterarCorDaConsola(BRANCO);
	printf(".##.\n");

	printf(".##..");
	alterarCorDaConsola(TABELA_CLARA);
	printf(" Sair  ");
	alterarCorDaConsola(TABELA_DOURADA);
	printf("- 5 -");

	
	alterarCorDaConsola(BRANCO);
	printf(".##.\n");
	printf(".###############################################################################################.\n");
	printf("########MENU: ");
}
