#include "Estacionamento.c"


int main() {
    int i, matricula, max=8, tempo;
    char op;
    //TipoPilha *pilha;
    //pilha = (TipoPilha *)malloc(sizeof(TipoPilha));
    //IniciarPilha(pilha);


    printf("[a]-Estancionar\n [b]-Remover Carro\n [c]-Verificar Vaga\n [d]- Organizar Estancionamento\n [e]-Mostrar carros estacionados (Mostre a matr�cula e o tempo de perman�ncia no parque)\n");
    scanf("%c", &op);

    do{
        switch(op){
        case 'a':
             printf("Estacionar");
            for (i=0;i<max;i++) {
                printf("Leitura da Matricula (%d) :",i);
                scanf("%d",&matricula);
                //Entrada(matricula, pilha);
                printf("Tempo no Estancionado, em minuto?");
                scanf("%d",&tempo);
                //Entrada(tempo, pilha);
                printf("Empilhou: %d \n", matricula);
            }
             break;
         case 'b':
            //Remover carro
            for(i=0;i<max;i++) {
                //matricula = Saida(pilha);
                printf ("Desempilhou: %d \n", matricula);
            }
             break;
         case 'c':
                //Verificar vaga
            break;
        case 'd':
            //d. Organizar estacionamento
            break;

        case 'e':
             //Mostrar carros estacionados (Mostre a matr�cula e o tempo de perman�ncia no parque
            break;
        default:
            printf("Operacao Errada");
        }
    }while(op != 'x');


    return 0;

}


