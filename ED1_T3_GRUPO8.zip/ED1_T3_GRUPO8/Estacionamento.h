#include <stdio.h>
#include <stdlib.h>

typedef struct No {
	int valor;
	struct No *prox;
}TipoNo;

typedef struct Pilha {
	TipoNo *topo;
	int tamanho;
}TipoPilha;


void IniciarPilha(TipoPilha *pilha);
int VerificaPilhaVazia(TipoPilha *pilha);
void Entrada(int x, TipoPilha *pilha);
int Saida(TipoPilha *pilha);
void MenoPrincipal();


//var

char hora[5];



