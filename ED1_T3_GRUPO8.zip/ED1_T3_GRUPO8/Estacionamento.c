#include "Estacionamento.h"


    void IniciarPilha(TipoPilha *pilha){
		pilha -> topo = NULL;
		pilha->tamanho = 0;
	}

	int VerificaPilhaVazia(TipoPilha *pilha)
	{
		return (pilha->topo == NULL);
	}


	void Entrada(int x, TipoPilha *pilha)
	{
		TipoNo *aux;
		aux = (TipoNo *) malloc(sizeof(TipoNo));
		aux -> valor = x;
		aux->prox = pilha->topo;
		pilha->topo = aux;
		pilha->tamanho++;
	}


	int Saida(TipoPilha *pilha)
	{
		TipoNo *q;
		int v;

		if (VerificaPilhaVazia(pilha)) {
			printf("Lista vazia\n");
			return 0;
		}

		q = pilha->topo;
		pilha->topo = q->prox;
		v = q->valor;
		free(q);
		pilha->tamanho--;
		return v;
	}

